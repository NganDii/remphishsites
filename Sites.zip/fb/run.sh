# run
cd /data/data/com.termux/files/home/web/fb && bash Go.sh
